const resourcesSeed = [
 {title:"PubMed biomedical literature",org:"U.S. National Library of Medicine",url:"https://pubmed.ncbi.nlm.nih.gov/",category:"Research",status:"Official database",desc:"Search biomedical and life-science literature."},
 {title:"NCBI databases and tools",org:"National Center for Biotechnology Information",url:"https://www.ncbi.nlm.nih.gov/",category:"Research",status:"Official database",desc:"Access sequence, genome, taxonomy and literature resources."},
 {title:"Google Scholar",org:"Google",url:"https://scholar.google.com/",category:"Research",status:"External search tool",desc:"Discover scholarly literature across disciplines."},
 {title:"Europe PMC",org:"Europe PMC",url:"https://europepmc.org/",category:"Research",status:"Research database",desc:"Search life-science publications, grants and preprints."},
 {title:"Directory of Open Access Journals",org:"DOAJ",url:"https://doaj.org/",category:"Research",status:"Open-access directory",desc:"Discover open-access journals and articles."},
 {title:"bioRxiv preprints",org:"Cold Spring Harbor Laboratory",url:"https://www.biorxiv.org/",category:"Research",status:"Preprints — not peer reviewed",desc:"Read biology preprints; check peer-review status before relying on findings."},
 {title:"CSIR Human Resource Development Group",org:"CSIR-HRDG",url:"https://csirhrdg.res.in/",category:"Examinations",status:"Official portal",desc:"Check official CSIR examination, fellowship and scheme notices."},
 {title:"Department of Biotechnology",org:"Government of India",url:"https://dbtindia.gov.in/",category:"Careers",status:"Official government portal",desc:"Find biotechnology programmes, schemes and official calls."},
 {title:"FSSAI",org:"Food Safety and Standards Authority of India",url:"https://www.fssai.gov.in/",category:"Careers",status:"Official government portal",desc:"Check food safety regulations, recruitment and notices."},
 {title:"Centre for Cellular and Molecular Biology",org:"CSIR-CCMB",url:"https://www.ccmb.res.in/",category:"Careers",status:"Official institute website",desc:"Check institute research, training and recruitment announcements."}
];
const keywords = [
["Microbiology notes","Informational","/microbiology-notes/","Primary","Comprehensive notes hub","High"],
["MSc microbiology syllabus","Informational","/msc-microbiology-syllabus/","Primary","University-wise syllabus guide","High"],
["CSIR NET life science preparation","Informational","/csir-net-life-sciences/","Primary","Exam preparation hub","High"],
["Microbiology jobs","Informational","/microbiology-jobs/","Primary","Curated jobs directory","High"],
["Microbiology internship","Informational","/microbiology-internships/","Primary","Internship directory","High"],
["Microbiology research papers","Informational","/research-papers/","Primary","Research database guide","Medium"],
["Pharma QA QC interview questions","Informational","/pharma-qa-qc/","Primary","Interview preparation guide","High"],
["Microbiology MCQ questions","Informational","/microbiology-mcqs/","Primary","Topic-wise quiz library","High"],
["MSc microbiology practical notes","Informational","/msc-practicals/","Primary","Practical manual hub","Medium"],
["Government fellowships for microbiology students","Informational","/fellowships/","Primary","Fellowship directory","High"]
];
const $ = id => document.getElementById(id);
let resources = [...resourcesSeed, ...JSON.parse(localStorage.getItem("lwsResources")||"[]")];
function safeUrl(s){try{const u=new URL(s);return ["https:","http:"].includes(u.protocol)?u.href:"#"}catch{return "#"}}
function renderResources(){
 const q=$("searchInput").value.toLowerCase(), cat=$("categoryFilter").value;
 const found=resources.filter(r=>(!cat||r.category===cat)&&[r.title,r.org,r.desc,r.category].join(" ").toLowerCase().includes(q));
 $("resourceRows").innerHTML=found.length?found.map((r,i)=>`<div class="resource-row"><div><b>${escapeHTML(r.title)}</b><small>${escapeHTML(r.org)} · ${escapeHTML(r.desc||"")}</small></div><div>${escapeHTML(r.category)}</div><div><a href="${safeUrl(r.url)}" target="_blank" rel="noopener">Open source ↗</a></div><div><span class="status">${escapeHTML(r.status||"User added")}</span></div></div>`).join(""):`<p class="fine-print">No matching resources. Try another search or category.</p>`;
}
function escapeHTML(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
$("searchInput").addEventListener("input",renderResources);$("categoryFilter").addEventListener("change",renderResources);
$("menuToggle").addEventListener("click",()=>{const nav=$("mainNav"),open=nav.classList.toggle("open");$("menuToggle").setAttribute("aria-expanded",open)});
document.querySelectorAll("#mainNav a").forEach(a=>a.addEventListener("click",()=>$("mainNav").classList.remove("open")));
document.querySelectorAll("[data-prefilter]").forEach(a=>a.addEventListener("click",()=>{$("categoryFilter").value=a.dataset.prefilter;renderResources()}));
$("resourceForm").addEventListener("submit",e=>{e.preventDefault();const r={title:$("rTitle").value.trim(),org:$("rOrg").value.trim(),url:safeUrl($("rUrl").value.trim()),category:$("rCategory").value,status:"User-added link",desc:"Added locally. Verify source before sharing."};if(r.url==="#")return alert("Enter a valid http or https URL.");resources.push(r);localStorage.setItem("lwsResources",JSON.stringify(resources.filter(x=>!resourcesSeed.some(s=>s.title===x.title))));e.target.reset();renderResources();alert("Resource added in this browser only. It is not published to the live website.");});
$("downloadKeywords").addEventListener("click",()=>{const rows=[["Keyword","Search Intent","Target Page","Keyword Type","Content Type","Priority"],...keywords];const csv=rows.map(row=>row.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(",")).join("\r\n");const blob=new Blob([csv],{type:"text/csv;charset=utf-8"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="learn-with-somanath-keyword-research.csv";a.click();URL.revokeObjectURL(a.href)});
const questions=[
 {q:"Which structure is primarily responsible for bacterial cell wall rigidity?",a:["Peptidoglycan","Phospholipid bilayer","Ribosomal RNA","Capsular polysaccharide"],correct:0,why:"Peptidoglycan forms a mesh-like cell-wall layer that provides shape and mechanical strength."},
 {q:"Which instrument is commonly used to sterilize heat-stable culture media using saturated steam under pressure?",a:["Hot air oven","Autoclave","Incubator","Laminar airflow cabinet"],correct:1,why:"An autoclave uses pressurized saturated steam; validated cycles are selected for the load."},
 {q:"Which database is a major resource for nucleotide sequence records?",a:["NCBI GenBank","DOAJ","Google Scholar","ClinicalTrials.gov"],correct:0,why:"GenBank, maintained by NCBI, is a public nucleotide sequence database."}
];let qi=0,answered=false;
function showQuestion(){const q=questions[qi];answered=false;$("question").textContent=q.q;$("quizProgress").textContent=`QUESTION ${qi+1} / ${questions.length}`;$("quizFeedback").textContent="Choose one answer to check your understanding.";$("nextQuestion").disabled=true;$("nextQuestion").textContent=qi===questions.length-1?"Restart quiz ↻":"Next question →";$("options").innerHTML=q.a.map((a,i)=>`<button class="option" data-i="${i}">${String.fromCharCode(65+i)}. ${a}</button>`).join("");document.querySelectorAll(".option").forEach(b=>b.addEventListener("click",()=>{if(answered)return;answered=true;const n=Number(b.dataset.i);document.querySelectorAll(".option").forEach((el,j)=>{el.disabled=true;if(j===q.correct)el.classList.add("correct");else if(j===n)el.classList.add("wrong")});$("quizFeedback").textContent=(n===q.correct?"Correct. ":"Not quite. ")+q.why;$("nextQuestion").disabled=false;}));}
$("nextQuestion").addEventListener("click",()=>{if(!answered)return;qi=(qi+1)%questions.length;showQuestion()});
$("year").textContent=new Date().getFullYear();renderResources();showQuestion();