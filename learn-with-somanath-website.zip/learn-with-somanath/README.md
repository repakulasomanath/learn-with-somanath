# Learn With Somanath — starter website

A responsive, lightweight static website built with HTML, CSS and vanilla JavaScript. It can be deployed to Cloudflare Pages without a build step.

## Included
- Responsive homepage and navigation
- Study, exam, research, career and pharma sections
- Searchable/filterable public resource directory
- Starter official-source links (not a live vacancy feed)
- Three-question microbiology practice quiz
- Downloadable keyword research CSV
- Demo resource manager using browser localStorage
- Basic SEO metadata, canonical placeholder, JSON-LD, sitemap, robots.txt and PWA manifest

## Run locally
Open `index.html` in a browser, or run a local static server from this directory:
`python -m http.server 8000`
Then visit `http://localhost:8000`.

## Deploy to Cloudflare Pages
1. Create a GitHub repository and upload all files in this folder to its root.
2. In Cloudflare, open **Workers & Pages → Create → Pages → Connect to Git**.
3. Select the repository and production branch.
4. Framework preset: **None**.
5. Build command: leave blank.
6. Build output directory: `/` (or `.` if the dashboard requires a relative directory).
7. Deploy. Cloudflare will provide a `*.pages.dev` URL.
8. Replace `https://YOUR-DOMAIN.example/` in `index.html` and `sitemap.xml` with your actual public URL. Update the canonical URL and schema URL too.
9. Add a custom domain in Pages if you own one.

## Important production limitations
- The resource manager is a local browser demo. It is NOT secure authentication, a shared database, or a real public admin CMS. Entries added in one browser do not appear for other visitors.
- Do not publish personal data or unverified vacancies. Before publishing each opportunity, record the original official notice URL, eligibility, deadline, fee, status and the date someone actually checked it.
- Search volume and keyword difficulty are not guessed in this starter sheet. Connect a keyword research source such as Google Keyword Planner or a trusted SEO platform before adding numerical estimates.
- The AI assistant, newsletter subscription, user accounts, bookmarks synced across devices, live job feeds and PDF library are not connected. They require backend services and API keys.
- Add your own original notes and PDFs. Only upload material you have rights to distribute; link to copyrighted papers rather than re-hosting them without permission.
- Configure Google Search Console and Analytics only after creating the relevant accounts and adding the correct verification/measurement IDs.

## Suggested production upgrade
Use a headless CMS or Cloudflare D1 with authenticated server-side admin routes. Protect create/update/delete operations with Cloudflare Access or another proper authentication provider. Never put admin secrets or private API keys in browser JavaScript.
